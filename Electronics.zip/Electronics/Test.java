package Electronics;

public class Test 
{
	public static void main(String[] args) 
	{
		Mobile m=new Mobile();
		m.mobiledetails();
		
	
		Lcd l=new Lcd();
		l.lcddetails();
		
		Laptop la=new Laptop();
		la.laptopdetails();
		
	}
}