package OOPSQ5;

public class TestMain5 {

	public static void main(String[] args) {

		A a = new A();

		a.sum(10, 20);

		B b = new B();

		b.sub(20, 10);

		C c = new C();

		c.mul(10, 20);

		D d = new D();

		d.div(10, 20);

	}
}
