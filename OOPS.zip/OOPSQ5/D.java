package OOPSQ5;

public class D extends C{

	@Override
	public void div(int a, int b) {
		
		int div=a/b;
		
		System.out.println("The div of the Two Numbers Is="+div);
		
	}
	
}
