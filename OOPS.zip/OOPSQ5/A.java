package OOPSQ5;

public class A extends CalcAbs {

	@Override
	public void sum(int a, int b) {
	
		int sum=a+b;
		
		System.out.println("The sum of the Two Numbers Is="+sum);
	}

	@Override
	public void sub(int a, int b) {
		
		
		
	}

	@Override
	public void mul(int a, int b) {
		
		
	}

	@Override
	public void div(int a, int b) {
		
		
	}

}
