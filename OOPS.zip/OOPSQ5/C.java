package OOPSQ5;

public class C extends B {

	
	@Override
	public void mul(int a, int b) {
		
		int mult=a*b;
		
		System.out.println("The mult of the Two Numbers Is="+mult);
		
	}
	
}
