package OOPSQ5;

public class B extends A {

	@Override
	public void sub(int a, int b) {
		
		int sub=a-b;
		
		System.out.println("The sub of the Two Numbers Is="+sub);
		
	}
	
	
}
