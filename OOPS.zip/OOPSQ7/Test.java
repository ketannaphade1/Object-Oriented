package OOPSQ7;

/*7.With the help of method overriding perform the string comparison. User will input two string and your task 
is to compare both the string one alphabets at a time. 
*/
public class Test {
	static int count = 0;

	public static int stringCompare(String str1, String str2) {

		for (int i = 0; i < str1.length() && i < str2.length(); i++) {

			if (str1.charAt(i) == str2.charAt(i)) {
				count++;
			}
		}
		if (count > 0) {
			System.out.println("Total number of alphabet matching=" + count);

		} else {
			System.out.println("No alphabet is matching");

		}

		return count;

	}
}
