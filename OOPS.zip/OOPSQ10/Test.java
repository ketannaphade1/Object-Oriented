package OOPSQ10;

import java.util.Date;

public class Test 
{
	public static void main(String[] args) {
		
		Employee employee=new Employee(101010, "Rahul", 1000.15,"Pune District", new Date(31/10/1994), new Date(27/07/2022));
		
		System.out.println(employee);
		
	}

}
