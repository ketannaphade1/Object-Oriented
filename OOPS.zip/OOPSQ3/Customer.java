package OOPSQ3;

/*3.Create Class Customer which will have following class members: - CustId, accountno, custname, cust_address, cust_dob, cust_account_opening_date, Branch_Obj. 


Class Branch  :- branch_id, branch_name, branch_address.

Class Customer_Account_Statement:-  CAID, CustId, amount, deposit_withdrawl, deposit_date. 

 Now you have to create Customer, Branch and CustomerAccountStatement class object. CustomerAccountStatement will have multiple records as one customer will deposit and withdrawal the amount. So you need to print the statement as per the CustomerId.

What is expected:- you will create multiple object of customer class. Also you have to create multiple object of the CustomerAccountStatement and while printing detail of CustomerAccountStatement you have to print detail of Customer. 
*/

public class Customer{ 
	
	private int CustId;
	private int accountno;
	private String custname;
	private String cust_dob;
	private String cust_account_opening_date;
	
//	private Branch Branch_Obj;
	
	Branch Branch_Obj=new Branch(44, "Jamod Branch", "NearBusStand");
//	
	
	public Customer(int custId, int accountno, String custname, String cust_dob, String cust_account_opening_date,
			String branch_Obj) {
		super();
		CustId = custId;
		this.accountno = accountno;
		this.custname = custname;
		this.cust_dob = cust_dob;
		this.cust_account_opening_date = cust_account_opening_date;
		
	}
	
	
	public int getCustId() {
		return CustId;
	}


	public void setCustId(int custId) {
		CustId = custId;
	}


	public int getAccountno() {
		return accountno;
	}


	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}


	public String getCustname() {
		return custname;
	}


	public void setCustname(String custname) {
		this.custname = custname;
	}


	public String getCust_dob() {
		return cust_dob;
	}


	public void setCust_dob(String cust_dob) {
		this.cust_dob = cust_dob;
	}


	public String getCust_account_opening_date() {
		return cust_account_opening_date;
	}


	public void setCust_account_opening_date(String cust_account_opening_date) {
		this.cust_account_opening_date = cust_account_opening_date;
	}


	public Branch getBranch_Obj() {
		return Branch_Obj;
	}


	public void setBranch_Obj(Branch branch_Obj) {
		Branch_Obj = branch_Obj;
	}


	


	@Override
	public String toString() {
		return "Customer [CustId=" + CustId + ", accountno=" + accountno + ", custname=" + custname + ", cust_dob="
				+ cust_dob + ", cust_account_opening_date=" + cust_account_opening_date + ", Branch_Obj=" + Branch_Obj
				+ "]";
	}
	
	
	

}
