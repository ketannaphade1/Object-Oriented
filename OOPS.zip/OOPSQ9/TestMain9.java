package OOPSQ9;

public class TestMain9 {

	public static void main(String[] args) throws CloneNotSupportedException {

		Test test1 = new Test(10, "Rahul", 1000.1, "Meter");

		Test test2 = (Test) test1.clone();

		System.out.println(test2);

		System.out.println(test2 instanceof Test);

	}

}
