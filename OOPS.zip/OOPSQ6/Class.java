package OOPSQ6;

/*6.With the help of method overriding create two functions which will find the maximum of 3 and 4 numbers. Also
write one generic function which can find maximum of N numbers.*/

public class Class {
	
	
	public void getNumbers(int number){
	
		System.out.println("For finding 3 ,4 and numbers");
	}

	
}
