package OOPSQ2;

public class TestMain {

	public static void main(String[] args) {

		Rectangle r = new Rectangle();
		r.findArea(10, 20, 50);

		Square s = new Square();
		s.findArea(0, 50, 50);

		Triangle t = new Triangle();
		t.findArea(40, 50, 30);

	}
}
