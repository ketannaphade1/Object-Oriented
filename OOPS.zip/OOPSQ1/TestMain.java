package OOPSQ1;

public class TestMain {

	public static void main(String[] args) {

		Employee employee = new Employee(1015956, "Ram", "Chinchwad Pune", "1/12/1994", 1000, "1/1/21", "hinjewadi",
				"development", "9999999999", "ram@gmail.com");

		Customer customer = new Customer(101, "chetak", "Railway Mumbai", "1/1/1984", "1/1/91", "moshi", "8888888888",
				"chetak@gmail.com");

		System.out.println(employee);
		System.out.println(customer);

	}

}
